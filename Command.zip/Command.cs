﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    abstract class $rootnamespace$
    {
        public abstract void Execute();
    }

    class ConcreteCommand : $rootnamespace$
    {
        Receiver receiver;
        public ConcreteCommand(Receiver r)
        {
            receiver = r;
        }
        public override void Execute()
        {
            receiver.Operation();
        }
    }

    class Receiver
    {
        public void Operation()
        { }
    }

    class Invoker
    {
        $rootnamespace$ command;
        public void SetCommand($rootnamespace$ c)
        {
            command = c;
        }
        public void Run()
        {
            command.Execute();
        }
    }
}
