﻿

namespace $rootnamespace$
{
    public sealed class $safeitemname$
    {
        private $safeitemname$()
        {
            
        }

        private static volatile $safeitemname$ _instance;

        private static readonly Object _lock = new Object();

        public static $safeitemname$ GetInstance()
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new $safeitemname$();
                    }
                }
            }
            return _instance;
        }
    }
}
